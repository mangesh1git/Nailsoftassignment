package com.assignmentapi.api.userservice;


import com.assignmentapi.api.entity.User;
import com.assignmentapi.api.model.UserRequest;

public interface UserService {

    public User saveuser(UserRequest userRequest);
    public User getUserById(Integer Id);
    public  User updateUser(Integer id ,User user) throws  NullPointerException;
    public void deleteUser(Integer id) ;
    public  User loginuser(UserRequest userRequest);
}
