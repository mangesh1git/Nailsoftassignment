package com.assignmentapi.api.userrepository;

import com.assignmentapi.api.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends CrudRepository<User, Serializable> {

public List<User> findByUsername(String username);
public User findById(Integer id);


}
