package com.assignmentapi.api.userservice;

import com.assignmentapi.api.entity.User;
import com.assignmentapi.api.model.UserRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.assignmentapi.api.userrepository.UserRepository;

import java.sql.Date;
import java.util.List;

@Service
public class
UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userrepository;

    @Override
    public User saveuser(UserRequest userRequest) {
        User us2 = null;

        List<User> userList = userrepository.findByUsername(userRequest.getUsername());
        if (userList.size() == 0) {
            User us = new User();
            us.setLastname(userRequest.getLastname());
            us.setPassword(userRequest.getPassword());
            us.setPhoneno(userRequest.getPhoneno());
            us.setEmailid(userRequest.getEmailid());
            us.setUsername(userRequest.getUsername());
            us.setActive(true);
            us.setCreatedon(new Date(System.currentTimeMillis()));
            us.setUpdatedon(new Date(System.currentTimeMillis()));
            us2 = userrepository.save(us);
        } else {
            User user1 = userList.get(0);
            user1.setUsername(userRequest.getUsername());
            user1.setPassword(userRequest.getPassword());
            user1.setPhoneno(userRequest.getPhoneno());
            user1.setEmailid(userRequest.getEmailid());
            user1.setLastname(userRequest.getLastname());
            us2 = userrepository.save(user1);

        }


        return userrepository.save(us2);
    }

    @Override
    public User getUserById(Integer Id) {
        User user = userrepository.findById(Id);
        return user;
    }

    @Override
    public User updateUser(Integer id, User user) throws NullPointerException {
        User us = userrepository.findById(id);
       
        User us11=null;
        if (us == null) {
            throw new NullPointerException("the given id is null");
        } 
        else {
        	us.setUsername(user.getUsername());
        	us.setLastname(user.getLastname());
        	us.setPassword(user.getPassword());
        	us.setPhoneno(user.getPhoneno());
        	us.setEmailid(user.getEmailid());
            us11 = userrepository.save(us);
        }
        return userrepository.save(us11);
    }

    @Override
    public void deleteUser(Integer id) {
        userrepository.deleteById(id);
    }

    @Override
    public User loginuser(UserRequest userRequest) {
        List<User> user = userrepository.findByUsername(userRequest.getUsername());
        if (userRequest.getPassword().equals(user.get(0).getPassword())) {
            return user.get(0);
        }return  null;

    }
}




