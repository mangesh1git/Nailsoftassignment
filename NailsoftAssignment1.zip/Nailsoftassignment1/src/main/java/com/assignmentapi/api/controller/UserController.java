package com.assignmentapi.api.controller;

import com.assignmentapi.api.entity.User;
import com.assignmentapi.api.model.UserRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.assignmentapi.api.userservice.UserService;
@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userservice;

    @PostMapping("/save")
    public ResponseEntity<User> saveUser(@RequestBody UserRequest userRequest){
        User user1 = userservice.saveuser(userRequest);
        System.out.println("uploading data>>");
        return ResponseEntity.ok().body(user1);
    }
    @GetMapping("/test")
    	public ResponseEntity<String> test(){
        System.out.println("testing api");
        return ResponseEntity.ok().body("test");
    }
    @GetMapping("/get/{id}")
    	public ResponseEntity<User>getUserById(@PathVariable("id") Integer id){
       User user= userservice.getUserById(id);
        System.out.println("geting data>>");
       return ResponseEntity.ok().body(user);
    }
    @PutMapping("/update/{id}")
    	public ResponseEntity<User> updateUser(@PathVariable("id") Integer id, @RequestBody User user) throws NullPointerException{
    	User us  =userservice.updateUser(id,user);
        System.out.println("updating data>>");
        return ResponseEntity.ok().body(us) ;
}
    @DeleteMapping("/delete/{id}")
    	public void deleteUserById(@PathVariable("id") Integer id) throws Exception{
        userservice.deleteUser(id);
}
    @PostMapping("/login")
    	public ResponseEntity<User> loginUser(@RequestBody UserRequest userRequest) {
        User user3 = userservice.loginuser(userRequest);
        System.out.println("login api>>");
        return ResponseEntity.ok().body(user3);

    }
}
